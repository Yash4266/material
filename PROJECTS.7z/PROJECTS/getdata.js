import array from "./store.js"

function fetchdata()
{
 let email =    document.getElementById("email").value
 let password = document.getElementById("password").value
 let  username= document.getElementById("username").value
 let x = {"Email":email,"password":password,"username":username}
 array.push(x)
console.log(array);

//  display()
}
function display()
{
    
}
